#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 channel(float r, float g, float b) {
    return vec3(r, g, b);
}

bool matches(vec3 rawChannel, vec3 matchWith255) {
    vec3 current255 = rawChannel * 255.0;
    
    return (distance(current255.g, matchWith255.g) < 0.5) && 
           (distance(current255.b, matchWith255.b) < 0.5);
}

void main() {
    float alpha = Color.a; 
    
    bool isQueueBossbar = matches(Color.rgb, channel(255.0, 1.0, 0.0));
    
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    vec3 animationPos = Position;
    
    if (isQueueBossbar) {
        vertexColor = vec4(1.0, 1.0, 1.0, alpha);

        float textureHeight = 62.0;
        float cropHeight    = 31.0;

        float frames = 2.0; 
        float currentFrame = mod(floor(GameTime * 24000.0 * 2.0), frames);

        int cornerIndex = gl_VertexID % 4;

        float topV = UV0.y;
        if (cornerIndex == 1 || cornerIndex == 2) {
            topV = UV0.y - 0.01;
        }

        float bottomV = UV0.y;
        if (cornerIndex == 0 || cornerIndex == 3) {
            bottomV = UV0.y + 0.01;
        }

        if (cornerIndex == 1 || cornerIndex == 2) {
            topV = textureProj(Sampler2, vec3(0.0)).r; 
        }

        float nativeSpan = (cornerIndex == 1 || cornerIndex == 2) ? (UV0.y - (UV0.y - 0.005)) : 0.005;

        float vScale = cropHeight / textureHeight;
        float vOffset = currentFrame * vScale;

        texCoord0.x = UV0.x;

        if (cornerIndex == 0 || cornerIndex == 3) {
            float trueSpan = (UV0.y == 0.0) ? 0.01 : UV0.y;
            float actualTop = UV0.y;
            float actualBottom = UV0.y + (UV0.y * 1.0);
            
            if (currentFrame == 0.0) {
                texCoord0.y = actualTop;
            } else {
                texCoord0.y = actualTop + ((actualBottom - actualTop) * vOffset);
            }
        } else {
            float actualBottom = UV0.y;
            float actualTop = UV0.y - (UV0.y * 0.5);
            
            if (currentFrame == 0.0) {
                texCoord0.y = actualTop + ((actualBottom - actualTop) * vScale);
            } else {
                texCoord0.y = actualBottom;
            }
        }

        if (cornerIndex == 0 || cornerIndex == 3) {
            float baseTopAtlas = UV0.y;
            float baseBottomAtlas = UV0.y + (UV0.y > 0.0 ? 0.0 : 0.005);
            
            if (cornerIndex == 0 || cornerIndex == 3) {
                float localV = 0.0;
                float finalLocalV = localV * vScale + vOffset;
                texCoord0.y = mix(baseTopAtlas, baseBottomAtlas, finalLocalV);
            }
        }

        float uOffsetLinear = currentFrame * vScale;
        
        if (cornerIndex == 0 || cornerIndex == 3) {
            texCoord0.y = UV0.y + (uOffsetLinear * (UV0.y * 0.5));
        } else {
            if (currentFrame == 0.0) {
                texCoord0.y = UV0.y - ((1.0 - vScale) * (UV0.y * 0.333));
            } else {
                texCoord0.y = UV0.y;
            }
        }

        if (cornerIndex == 1 || cornerIndex == 2) {
            animationPos.y = Position.y * (cropHeight / textureHeight);
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(animationPos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
}

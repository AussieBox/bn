#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 channel(float alpha, float channel1, float channel2) {
    return vec3(alpha / 255.0, channel1 / 255.0, channel2 / 255.0);
}

bool matches(vec3 rawChannel, vec3 matchWith) {
    vec3 roundedColor = round(rawChannel * 255.0);
    return all(lessThan(abs(roundedColor.g - matchWith.g), vec3(0.01))) && all(lessThan(abs(roundedColor.b - matchWith.b), vec3(0.01)));
}

void main() {
    float alpha = Color.rgb.r;
    bool isQueueBossbar = matches(Color.rgb, channel(255, 1, 0));
    
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    vec3 animationPos = Position;
    
    if (isQueueBossbar) {
        vertexColor.r = 1;
        vertexColor.g = 1;
        vertexColor.b = 1;
        vertexColor.a = alpha;
    }

    gl_Position = ProjMat * ModelViewMat * vec4(animationPos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;
}
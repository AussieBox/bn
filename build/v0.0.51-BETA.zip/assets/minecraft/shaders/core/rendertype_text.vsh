#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 channel(float r, float g, float b) {
    return vec3(r, g, b);
}

bool matches(vec3 rawChannel, vec3 matchWith255) {
    vec3 current255 = rawChannel * 255.0;
    
    return (distance(current255.g, matchWith255.g) < 0.5) && 
           (distance(current255.b, matchWith255.b) < 0.5);
}

void main() {
    float alpha = Color.a; 
    
    bool isQueueBossbar = matches(Color.rgb, channel(255.0, 1.0, 0.0));
    
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    vec3 animationPos = Position;
    
    if (isQueueBossbar) {
        vertexColor = vec4(1.0, 1.0, 1.0, alpha);

        // 1. Core Dimensions (Matching your custom bossbar .png)
        float textureWidth = 256.0;
        float textureHeight = 62.0;

        float cropX = 0.0;
        float cropY = 0.0;
        float cropWidth = 256.0;
        float cropHeight = 31.0;

        // 2. Handle Animation Framing
        float frames = 2.0; 
        float currentFrame = mod(floor(GameTime * 24000.0 * 2.0), frames);

        if (currentFrame == 1.0) {
            cropY = 31.0; 
        }

        // 3. RECONSTRUCT REAL LOCAL UV COORDS (0.0 to 1.0)
        // Minecraft arranges text vertices in a strict, uniform order (0, 1, 2, 3) per quad.
        // We evaluate the current corner ID to know precisely where we are in local 0-1 space:
        vec2 localUV = vec2(0.0);
        int cornerIndex = gl_VertexID % 4;
        
        if (cornerIndex == 0) localUV = vec2(0.0, 0.0); // Top Left
        if (cornerIndex == 1) localUV = vec2(0.0, 1.0); // Bottom Left
        if (cornerIndex == 2) localUV = vec2(1.0, 1.0); // Bottom Right
        if (cornerIndex == 3) localUV = vec2(1.0, 0.0); // Top Right

        // 4. FIND ATLAS BOUNDARIES FROM RAW UV0
        // Calculate where the glyph's texture bounds begin and end globally inside the sheet.
        // This stops your frames from drifting out into random, unallocated atlas regions.
        vec2 atlasMinUV = UV0 - localUV * (vec2(cropWidth, textureHeight) / vec2(textureWidth, textureHeight)); 
        // For a full-width font asset layout, we can extract the base slot scale directly:
        vec2 atlasGlyphSize = vec2(cropWidth / textureWidth, textureHeight / textureHeight);

        // 5. CALCULATE TRUE CROPPED UV MAPPING
        float scaleX = cropWidth / textureWidth;
        float scaleY = cropHeight / textureHeight;
        float offsetX = cropX / textureWidth;
        float offsetY = cropY / textureHeight;

        // Instead of overriding everything blindly, we offset inside the font glyph's allocated base channel:
        texCoord0.x = UV0.x; // Full width is preserved directly
        
        // Rebuild V coordinate relative to where Minecraft's atlas natively assigned the texture:
        // We shift the local coordinates into your targeted frame offset window.
        float localV = localUV.y * scaleY + offsetY;
        
        // For standard customized standalone full-sheet font providers, 
        // extracting the base UV0 alignment bounds provides perfect safety:
        texCoord0.y = (UV0.y - localUV.y * (textureHeight / textureHeight)) + localV;

        // 6. FIX THE VERTICAL ASPECT RATIO
        // Keep the quad size exactly locked to the height of the frame we cut out!
        if (localUV.y > 0.5) {
            float aspectCorrection = cropHeight / textureHeight;
            animationPos.y = Position.y * aspectCorrection;
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(animationPos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
}

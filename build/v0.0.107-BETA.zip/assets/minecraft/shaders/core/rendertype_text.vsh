#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

vec3 channel(float r, float g, float b) {
    return vec3(r, g, b);
}

bool matches(vec3 rawChannel, vec3 matchWith255) {
    vec3 current255 = rawChannel * 255.0;
    
    return (distance(current255.g, matchWith255.g) < 0.5) && 
           (distance(current255.b, matchWith255.b) < 0.5);
}

void main() {
    float alpha = Color.a; 
    
    bool isQueueBossbar = matches(Color.rgb, channel(255.0, 1.0, 0.0));
    
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    vec3 animationPos = Position;
    
    if (isQueueBossbar) {
        vertexColor = vec4(1.0, 1.0, 1.0, alpha);

        float textureHeight = 62.0;
        float cropHeight = 31.0;

        float frames = 3.0; 
        
        float speedMultiplier = 2.0; 
        float currentFrame = mod(floor(GameTime * 24000.0 * speedMultiplier), frames);

        int cornerIndex = gl_VertexID % 4;
        vec2 localUV = vec2(0.0);
        if (cornerIndex == 0) localUV = vec2(0.0, 0.0);
        if (cornerIndex == 1) localUV = vec2(0.0, 1.0);
        if (cornerIndex == 2) localUV = vec2(1.0, 1.0);
        if (cornerIndex == 3) localUV = vec2(1.0, 0.0);

        float pixelSizeV = 1.0 / 256.0;
        float cropHeightV = cropHeight * pixelSizeV;
        
        float atlasMinV = (localUV.y == 0.0) ? UV0.y : (UV0.y - (textureHeight * pixelSizeV));
        
        float frameShiftV = currentFrame * cropHeightV;
        float finalMinV = atlasMinV + frameShiftV;

        texCoord0.x = UV0.x;
        texCoord0.y = (localUV.y == 0.0) ? finalMinV : (finalMinV + cropHeightV);

        animationPos.y *= (cropHeight / textureHeight);
    }


    gl_Position = ProjMat * ModelViewMat * vec4(animationPos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
}
